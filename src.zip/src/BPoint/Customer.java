
package BPoint;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    private int customerId;
    private String customerName;
    private String customerPassword;
    private String contactPosition;
    private String contactEmail;
    private String contactName;
    private String emailBody;
    private String reference;
    @ManyToOne
    private BusyPoint busyP;

    
 
    
    
    public Customer(){
        
    }
    
            
    
    public Customer (int companyId, String companyName, String contactPosition, String contactEmail,
            String contactName, String emailBody, String reference){
        this.customerName = companyName;
        this.customerId = companyId;
        this.contactPosition = contactPosition;
        this.contactEmail = contactEmail;
        this.contactName = contactName;
       
        this.customerPassword = customerName.substring(0,3)+companyId/1000;
        this.reference = reference;
    }

    protected String getContactEmail() {
        return contactEmail;
    }

    protected String getContactName() {
        return contactName;
    }

    protected String getContactPosition() {
        return contactPosition;
    }

    protected int getCustomerId() {
        return customerId;
    }

    protected String getCustomerName() {
        return customerName;
    }

    protected String getCustomerPassword() {
        return customerPassword;
    }

    protected String getEmailBody() {
        return emailBody;
    }

    protected void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    protected void setContactName(String contactName) {
        this.contactName = contactName;
    }

    protected void setContactPosition(String contactPosition) {
        this.contactPosition = contactPosition;
    }

    protected void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    protected void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    protected void setCustomerPassword(String customerPassword) {
        this.customerPassword = customerPassword;
    }

    protected void setEmailBody(String emailBody) {
        this.emailBody = emailBody;
    }

    protected String getReference() {
        return reference;
    }

    protected void setReference(String reference) {
        this.reference = reference;
    }
    
    
}
