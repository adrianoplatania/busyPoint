
package BPoint;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;


@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class MarketingPromotion implements Serializable {

    protected static long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    protected Long id;
    protected String promotionName;
    protected double costPromotion;
    protected boolean isComplete;
    protected boolean isPaid;
    
    protected MarketingPromotion(){
        
    }
    
    protected MarketingPromotion(String promotionName,
            double costPromotion,boolean isComplete,boolean isPaid){
        this.promotionName = promotionName;
        this.costPromotion = costPromotion;
        this.isComplete = isComplete;
        this.isPaid = isPaid;
        
    }
    

    protected Long getId() {
        return id;
    }

    protected void setId(Long id) {
        this.id = id;
    }

    protected double getCostPromontion() {
        return costPromotion;
    }

     protected void setCostPromontion(double costPromotion) {
        this.costPromotion = costPromotion;
    }

    protected String getPromotionName() {
        return promotionName;
    }

    protected static long getSerialVersionUID() {
        return serialVersionUID;
    }

    protected boolean isIsComplete() {
        return isComplete;
    }

    protected boolean isIsPaid() {
        return isPaid;
    }

  

    protected void setIsComplete(boolean isComplete) {
        this.isComplete = isComplete;
    }

    protected void setIsPaid(boolean isPaid) {
        this.isPaid = isPaid;
    }

   
    protected void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }

    protected static void setSerialVersionUID(long aSerialVersionUID) {
        serialVersionUID = aSerialVersionUID;
    }

    
    
}
