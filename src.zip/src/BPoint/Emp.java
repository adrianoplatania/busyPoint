
package BPoint;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;



@Entity
public class Emp implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
     private int empId;
    
    private String empName;
    
    private String empEmail;
    
    private Address empAddress;
    
    private String empContactNo;
    
    private String empGrade;
    
    private double empSalary;
    @ManyToOne
    private EmpDept dept;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

 
    
    public Emp(){
        
    }
    
    
    public Emp(int empId, String empName, String empEmail, Address empAddress, String empContactNo, 
            String empGrade, double empSalary, EmpDept dept){
        
        this.empId = empId;
        this.empName = empName;
        this.empEmail = empEmail;
        this.empAddress = empAddress;
        this.empContactNo = empContactNo;
        this.empGrade = empGrade;
        this.empSalary = empSalary;
        this.dept = dept; 
        
        
    }

 
    
    
    public int getEmpId() {
        return empId;
    }

    
    public void setEmpId(int empId) {
        this.empId = empId;
    }

    
    public String getEmpName() {
        return empName;
    }

    
    public void setEmpName(String empName) {
        this.empName = empName;
    }

    
    public String getEmpEmail() {
        return empEmail;
    }

    
    public void setEmpEmail(String empEmail) {
        this.empEmail = empEmail;
    }

    
    public Address getEmpAddress() {
        return empAddress;
    }

    
    public void setEmpAddress(Address empAddress) {
        this.empAddress = empAddress;
    }

    
    public String getEmpContactNo() {
        return empContactNo;
    }

   
    public void setEmpContactNo(String empContactNo) {
        this.empContactNo = empContactNo;
    }

   
    public String getEmpGrade() {
        return empGrade;
    }

    
    public void setEmpGrade(String empGrade) {
        this.empGrade = empGrade;
    }

    
    public double getEmpSalary() {
        return empSalary;
    }

    
    public void setEmpSalary(double empSalary) {
        this.empSalary = empSalary;
    }
    
    
}
