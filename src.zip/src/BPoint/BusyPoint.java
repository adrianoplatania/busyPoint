
package BPoint;

import java.io.Serializable;
import java.util.ArrayList;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class BusyPoint implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String companyName;
    private Address companyAddress;
    private int companyId;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER,mappedBy ="bp")
    private ArrayList<EmpDept> depts;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER,mappedBy ="busyP")
    //association
    private ArrayList<Customer> customers;
    
    private BusyPoint bp;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    private BusyPoint(){
        
    }

    private BusyPoint(String companyName, Address companyAddress, int companyId){
    this.companyName=companyName;
    this.companyAddress = companyAddress;
    this.companyId = companyId;
    depts = new ArrayList<EmpDept>();
    customers =  new ArrayList<Customer>();
    
    }
 //aggregation
   public void addDept(EmpDept dept){
       
       depts.add(dept);
       
       
   }
   
   
   public void addCustomer(Customer customer){
       customers.add(customer);
   }
   
   
   
   
    public String getCompanyName() {
        return companyName;
    }

    
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

   
    public Address getCompanyAddress() {
        return companyAddress;
    }

    
    public void setCompanyAddress(Address companyAddress) {
        this.companyAddress = companyAddress;
    }

    
    public int getCompanyId() {
        return companyId;
    }

   
    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }
}
