
package BPoint;

import java.io.Serializable;
import java.util.ArrayList;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@Entity
public class EmpDept implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String deptName;
    private int invoiceId;
    @ManyToOne
    private BusyPoint bp;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER,mappedBy= "dept")
    private ArrayList<Emp> employees;
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

     
    
    public EmpDept(){
        
        
    }
    
    
   //association
    public EmpDept(String deptName, int invoiceId, BusyPoint bp){
        
        this.deptName = deptName;
        this.invoiceId = invoiceId;
        this.bp = bp;
        employees = new ArrayList<Emp>();
        
    }
    
    //composition
    public void addEmp(int empId, String empName, String empEmail, Address empAddress, String empContactNo, 
            String empGrade, double empSalary, EmpDept dept){
        Emp employee = new Emp(empId, empName, empEmail, empAddress, empContactNo, empGrade, empSalary, dept);
        employees.add(employee);
    }

    

    
}
