
package BPoint;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;



public class Application {

    public static void main(String[] args){
        Application app = new Application();
      
      
        MarketingPromotion billboard = new PosterPromo("JCDecaux",250000,false,false);
        app.persist(billboard);
        MarketingPromotion nsl = new NewsLetterPromo("MailChimp",10000,false,false);
        app.persist(nsl);
        MarketingPromotion tv = new TVPromo ("BBC 1",1000000, false, false);
        app.persist(tv);
        MarketingPromotion magazine = new MagazinePromo("Vogue",50000, false, false);
        app.persist(magazine);
        MarketingPromotion radio = new RadioPromo("Heart Radio", 15000, false, false);
        app.persist(radio);
        MarketingPromotion web = new WebPromo("Facebook", 5000, false, false);
        app.persist(web);
         MarketingPromotion newspaper = new NewsPaperPromo("The Guardian", 8000, false, false);
        app.persist(newspaper);
        
    }
          
    //This method allows newly persisted instances to be inserted into the DB using Persistence.

    public void persist(Object object) {
        try{
        EntityManagerFactory emf = javax.persistence.Persistence.createEntityManagerFactory("BusyPointLtdPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.persist(object);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
        }catch(Exception x){
            System.out.println(x);
        }
    }
    //This method is called to check if the Id and the password of Busy Point Customers match
    
    public int checkDetails(int id, String pass){
        Customer c = null;
        int ok = 0;
        EntityManagerFactory emf = javax.persistence.Persistence.createEntityManagerFactory("BusyPointLtdPU");
        EntityManager em = emf.createEntityManager();
        try {
            c = em.find(Customer.class, id);
            if (c.getCustomerPassword().equals(pass)){
                ok = 1;
            }
            }catch (Exception e) {
            e.printStackTrace();
        } finally {
            em.close();
        }
        
        
     return ok;   
    }
    
    /*This method is called to look for the Marketing Promotion through their unique Id and 
       returns the cost of the Promo 
    */
 
    public double findtMarketingPromotion(Long id) {
        MarketingPromotion mktpromo = null;
        EntityManagerFactory emf = javax.persistence.Persistence.createEntityManagerFactory("BusyPointLtdPU");
        EntityManager em = emf.createEntityManager();
        try {
            mktpromo  = em.find(MarketingPromotion.class, id);
            
         
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            em.close();
        }          
        return mktpromo.getCostPromontion();
    }
    
 
    public List<MarketingPromotion> findMarketingPromoList() {
        List<MarketingPromotion> marketingPromotions =  null;
        EntityManagerFactory emf = javax.persistence.Persistence.createEntityManagerFactory("BusyPointLtdPU");
        EntityManager em = emf.createEntityManager();
        try {
            String qry = "from MarketingPromotion m ";                
            marketingPromotions =  em.createQuery(qry).getResultList();
            return marketingPromotions;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            em.close();
        }          
        return marketingPromotions;
    }    
    
    //This method is used to find the customer in the DB and update the email body column
    public void emailBody(int id,String email){
        //A customer instance is created
        Customer c = null;
        EntityManagerFactory emf = javax.persistence.Persistence.createEntityManagerFactory("BusyPointLtdPU");
        EntityManager em = emf.createEntityManager();
        
        
        try{
            
            //this will use the find() method and look for the id the Customer class
            c = em.find(Customer.class, id);
            em.getTransaction().begin();
            //this will set the email body
            c.setEmailBody(email);
            //the transaction gets committed
            em.getTransaction().commit();
            
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void customerRef(int id,String ref){
        //A customer instance is created
        Customer c = null;
        EntityManagerFactory emf = javax.persistence.Persistence.createEntityManagerFactory("BusyPointLtdPU");
        EntityManager em = emf.createEntityManager();
        
        
        try{
            
            //this will use the find() method and look for the id the Customer class
            c = em.find(Customer.class, id);
            em.getTransaction().begin();
            //this will set the reference
            c.setReference(ref);
            //the transaction gets committed
            em.getTransaction().commit();
            
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    /*This method is called to generate a customer id by adding 1 from the last
      customer id on our Customer Table.
      When Customer sends a request to the server, to sign up, system sets a
      unique id and generate a password. This unique id would be used later to authenticate 
      the client together with its password when he wants to interact again with the server.
*/
        public int customerCounter() {
        List<Customer> customers =  null;
        EntityManagerFactory emf = javax.persistence.Persistence.createEntityManagerFactory("BusyPointLtdPU");
        EntityManager em = emf.createEntityManager();
        try {
            String qry = "from Customer c ";                
            customers =  em.createQuery(qry).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            em.close();
        }          
        
        return customers.size();
    }    
     
         
}
