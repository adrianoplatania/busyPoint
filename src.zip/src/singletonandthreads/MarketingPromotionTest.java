package singletonandthreads;

import java.util.LinkedList;

public class MarketingPromotionTest {

    public static void main(String[] args) {

        // A new instance of Singleton is created
        Singleton newInstance = Singleton.getInstance();

        // Get unique id for instance object
        System.out.println("1st Instance ID: " + System.identityHashCode(newInstance));

        // Get all of the promotions stored in the List
        System.out.println(newInstance.getAdvtList());
        
        // Customer 1 selects 1 promotion

        LinkedList<String> customerOnePromotions = newInstance.getPromotions(1);

        System.out.println("Customer 1: " + customerOnePromotions);

        //System.out.println(newInstance.getAdvtList());

        // If we try to make another instance of Singleton it won't work because the constructor is private
        // We get a new instance using getInstance
        Singleton instanceTwo = Singleton.getInstance();

        // Get unique id for the new instance object
        System.out.println("2nd Instance ID: " + System.identityHashCode(instanceTwo));

        // This returns the value of the first instance created
        System.out.println(instanceTwo.getAdvtList());

        // Customer 2 selects 2 promotions
        LinkedList<String> customerTwoPromotions = newInstance.getPromotions(2);
        
        

        System.out.println("Customer 2: " + customerTwoPromotions);

    }

}
