package singletonandthreads;

import java.util.Arrays;
import java.util.LinkedList;

public class Singleton {

    private static Singleton firstInstance = null;

    String[] marketingPromotions = {"Vogue", "GQ", "Marie Claire", "Newsletter MailChimp",
        "The Guardian", "The Times", "The Evening Standard ", "Facebook", "Virgin Radio",
        "Poster JCDecaux", "Poster Fiorucci", "Twitter", "Instagram", "Radio Heart", "BBC 1",
        "BBC 2", "BBC 4"};

    private LinkedList<String> promoList = new LinkedList<String>(Arrays.asList(marketingPromotions));


    static boolean inizialized = false;

    // Created to keep users from instantiation
    // Only Singleton will be able to instantiate this class
    private Singleton() {
    }

    // This create a first instance
    
    synchronized public static Singleton getInstance() {
        if (!inizialized) {
            inizialized = true;
            firstInstance = new Singleton();
        }
        
        return firstInstance;

    }
    
    //This get the entire Promotion List 

    synchronized public LinkedList<String> getAdvtList() {

        return promoList;

    }

    synchronized public LinkedList<String> getPromotions(int howManyPromotions) {

        // Promotions to be returned to the user
        LinkedList<String> promotionsToSend = new LinkedList<>();

        // Cycle through the LinkedList while adding the starting
        // Strings to the LinkedList while deleting them from advtList
        for (int i = 0; i < howManyPromotions; i++) {

            promotionsToSend.add(firstInstance.promoList.remove(0));

        }

        // Return the number of promotions requested
        return promotionsToSend;

    }

}
