package singletonandthreads;

public class MarketingPromotionTestThreads {

    public static void main(String[] args) {

        // Creates 10 cuncurrently Threads in only two seconds
        

        
        for (int i = 0; i < 10; i++) {
            new Thread(new GetThePromo()).start();
        }
        

    }

}
