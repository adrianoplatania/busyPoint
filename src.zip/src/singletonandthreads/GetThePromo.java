package singletonandthreads;

import java.util.LinkedList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GetThePromo implements Runnable {

    static int num = 0;
    int myId = num;

    public GetThePromo() {
        num++;
    }

    @Override
    public void run() {
        Random rand = new Random();
        // A new instance of Singleton is created
        Singleton newInstance = Singleton.getInstance();
        
      //Thread will sleep for 1000 milliseconds.
        try {
            Thread.sleep(rand.nextInt(1000));

            // Get all of the promotions stored in the List
            System.out.println(myId + " " + newInstance.getAdvtList());
            
            // Get all of the promotions chosen by the customer

            LinkedList<String> customerOnePromotions = newInstance.getPromotions(1);
            
            Thread.sleep(rand.nextInt(1000));
            System.out.println("Customer " + myId + " : " + customerOnePromotions);
            
            //Display Promotions have been received
            
            Thread.sleep(rand.nextInt(1000));
            System.out.println(myId + " Promotions received");
            
        } catch (InterruptedException ex) {
            Logger.getLogger(GetThePromo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
